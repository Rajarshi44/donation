import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const stats = {
  mealsSaved: 1200,
  foodTypes: 8,
  leaderboard: [
    { name: 'GreenHearts', value: 520 },
    { name: 'FoodAngels', value: 410 },
    { name: 'Fruit4All', value: 270 },
  ],
};

const ProgressBar = ({ value, max, color }: { value: number; max: number; color: string }) => (
  <View style={styles.progressBarBg}>
    <View style={[styles.progressBarFill, { width: `${(value / max) * 100}%`, backgroundColor: color }]} />
  </View>
);

const DashboardScreen = () => (
  <View style={styles.container}>
    <Text style={styles.header}>📊 Dashboard</Text>
    <View style={styles.card}>
      <Text style={styles.statTitle}>🍽️ Meals Saved</Text>
      <Text style={styles.statValue}>{stats.mealsSaved}</Text>
      <ProgressBar value={stats.mealsSaved} max={2000} color="#ffcc00" />
    </View>
    <View style={styles.card}>
      <Text style={styles.statTitle}>🥗 Food Types Rescued</Text>
      <Text style={styles.statValue}>{stats.foodTypes}</Text>
      <ProgressBar value={stats.foodTypes} max={20} color="#00ccff" />
    </View>
    <View style={styles.card}>
      <Text style={styles.statTitle}>🏆 Volunteer Leaderboard</Text>
      {stats.leaderboard.map((entry, i) => (
        <View key={entry.name} style={styles.leaderRow}>
          <Text style={styles.leaderName}>{i + 1}. {entry.name}</Text>
          <ProgressBar value={entry.value} max={600} color="#ff0066" />
        </View>
      ))}
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { fontSize: 36, fontWeight: 'bold', color: '#000', marginVertical: 16, textShadowColor: '#00ccff', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2 },
  card: { backgroundColor: '#fff', borderWidth: 4, borderColor: '#000', borderRadius: 18, marginVertical: 12, padding: 18, shadowColor: '#000', shadowOffset: { width: 8, height: 8 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 8 },
  statTitle: { fontSize: 24, fontWeight: 'bold', color: '#ff0066', marginBottom: 4 },
  statValue: { fontSize: 40, fontWeight: 'bold', color: '#ffcc00', marginBottom: 8, textShadowColor: '#000', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2 },
  progressBarBg: { height: 18, backgroundColor: '#eee', borderRadius: 8, borderWidth: 2, borderColor: '#000', marginBottom: 8, overflow: 'hidden' },
  progressBarFill: { height: 18, borderRadius: 8 },
  leaderRow: { marginBottom: 8 },
  leaderName: { fontSize: 18, fontWeight: 'bold', color: '#000', marginBottom: 2 },
});

export default DashboardScreen;
