import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import BlockyButton from '../../components/BlockyButton';
import DonationCard from '../../components/DonationCard';
import { useDonations } from '../../context/DonationsContext';

const NGO_NAME = 'GreenHearts';

const NGOScreen = () => {
  const { donations, updateDonationStatus } = useDonations();
  const available = donations.filter(d => d.status === 'LISTED');
  const reserved = donations.filter(d => d.status === 'RESERVED' && d.ngo === NGO_NAME);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>🥗 Available Donations</Text>
      {available.length === 0 && <Text style={styles.empty}>No donations available.</Text>}
      {available.map(donation => (
        <View key={donation.id}>
          <DonationCard donation={donation} />
          <BlockyButton
            text="RESERVE 🚀"
            color="#00ccff"
            onPress={() => updateDonationStatus(donation.id, 'RESERVED', NGO_NAME)}
          />
        </View>
      ))}
      <Text style={styles.header}>My Reserved</Text>
      {reserved.length === 0 && <Text style={styles.empty}>No reserved donations.</Text>}
      {reserved.map(donation => (
        <DonationCard key={donation.id} donation={donation} />
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { fontSize: 32, fontWeight: 'bold', color: '#000', marginVertical: 16, textShadowColor: '#00ccff', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2 },
  empty: { fontSize: 18, color: '#ff0066', marginBottom: 12, fontStyle: 'italic' },
});

export default NGOScreen;
