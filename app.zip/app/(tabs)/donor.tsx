import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import BlockyButton from '../../components/BlockyButton';
import DonationCard from '../../components/DonationCard';
import { useDonations } from '../../context/DonationsContext';

const DonorScreen = () => {
  const { donations, createDonation } = useDonations();
  const [form, setForm] = useState({
    title: '',
    quantity: '',
    address: '',
    timeWindow: '',
    notes: '',
  });

  const handleChange = (key: string, value: string) => {
    setForm({ ...form, [key]: value });
  };

  const handleSubmit = () => {
    if (!form.title || !form.quantity || !form.address || !form.timeWindow) return;
    createDonation(form);
    setForm({ title: '', quantity: '', address: '', timeWindow: '', notes: '' });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>🍕 Create Donation</Text>
      <View style={styles.form}>
        <TextInput style={styles.input} placeholder="Title" value={form.title} onChangeText={v => handleChange('title', v)} />
        <TextInput style={styles.input} placeholder="Quantity" value={form.quantity} onChangeText={v => handleChange('quantity', v)} />
        <TextInput style={styles.input} placeholder="Address" value={form.address} onChangeText={v => handleChange('address', v)} />
        <TextInput style={styles.input} placeholder="Time Window" value={form.timeWindow} onChangeText={v => handleChange('timeWindow', v)} />
        <TextInput style={styles.input} placeholder="Notes" value={form.notes} onChangeText={v => handleChange('notes', v)} />
        <BlockyButton text="Add Donation" onPress={handleSubmit} color="#ffcc00" />
      </View>
      <Text style={styles.header}>My Donations</Text>
      {donations.filter(d => !d.ngo || d.status === 'LISTED').map(donation => (
        <DonationCard key={donation.id} donation={donation} />
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { fontSize: 32, fontWeight: 'bold', color: '#000', marginVertical: 16, textShadowColor: '#ffcc00', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2 },
  form: { backgroundColor: '#ffcc00', borderWidth: 4, borderColor: '#000', borderRadius: 16, padding: 16, marginBottom: 24, shadowColor: '#000', shadowOffset: { width: 6, height: 6 }, shadowOpacity: 0.3, shadowRadius: 6 },
  input: { backgroundColor: '#fff', borderWidth: 2, borderColor: '#000', borderRadius: 8, fontSize: 20, marginBottom: 12, padding: 10 },
});

export default DonorScreen;
