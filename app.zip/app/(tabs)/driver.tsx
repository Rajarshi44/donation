import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import BlockyButton from '../../components/BlockyButton';
import DonationCard from '../../components/DonationCard';
import { useDonations } from '../../context/DonationsContext';

const DRIVER_NAME = 'Alex';

const DriverScreen = () => {
  const { donations, updateDonationStatus } = useDonations();
  const [activeId, setActiveId] = useState<string | null>(null);

  // Donations needing pickup
  const jobs = donations.filter(d => (d.status === 'LISTED' || d.status === 'RESERVED'));
  // Active job (ASSIGNED, PICKED UP, DELIVERED)
  const active = donations.find(d => d.driver === DRIVER_NAME && (d.status === 'ASSIGNED' || d.status === 'PICKED UP'));

  const handleAccept = (donationId: string) => {
    updateDonationStatus(donationId, 'ASSIGNED', undefined, DRIVER_NAME);
    setActiveId(donationId);
  };

  const handleNextStatus = (donation: any) => {
    if (donation.status === 'ASSIGNED') updateDonationStatus(donation.id, 'PICKED UP');
    else if (donation.status === 'PICKED UP') updateDonationStatus(donation.id, 'DELIVERED');
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>🚚 Jobs to Accept</Text>
      {jobs.length === 0 && <Text style={styles.empty}>No jobs available.</Text>}
      {jobs.map(donation => (
        <View key={donation.id}>
          <DonationCard donation={donation} />
          <BlockyButton
            text="ACCEPT JOB 🚚"
            color="#ff0066"
            onPress={() => handleAccept(donation.id)}
          />
        </View>
      ))}
      <Text style={styles.header}>Active Job</Text>
      {active ? (
        <View style={styles.activeCard}>
          <DonationCard donation={active} />
          <View style={styles.statusRow}>
            <Text style={styles.statusStep}>
              {active.status === 'ASSIGNED' ? '🟡 ASSIGNED' : '✅ ASSIGNED'}
            </Text>
            <Text style={styles.statusStep}>
              {active.status === 'PICKED UP' ? '🟡 PICKED UP' : active.status === 'DELIVERED' ? '✅ PICKED UP' : '⬜ PICKED UP'}
            </Text>
            <Text style={styles.statusStep}>
              {active.status === 'DELIVERED' ? '✅ DELIVERED' : '⬜ DELIVERED'}
            </Text>
          </View>
          {active.status !== 'DELIVERED' && (
            <BlockyButton
              text={active.status === 'ASSIGNED' ? 'Mark as PICKED UP' : 'Mark as DELIVERED'}
              color="#ffcc00"
              onPress={() => handleNextStatus(active)}
            />
          )}
        </View>
      ) : (
        <Text style={styles.empty}>No active job.</Text>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { fontSize: 32, fontWeight: 'bold', color: '#000', marginVertical: 16, textShadowColor: '#ff0066', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 2 },
  empty: { fontSize: 18, color: '#00ccff', marginBottom: 12, fontStyle: 'italic' },
  activeCard: { backgroundColor: '#00ccff', borderWidth: 4, borderColor: '#000', borderRadius: 16, padding: 12, marginVertical: 12, shadowColor: '#000', shadowOffset: { width: 6, height: 6 }, shadowOpacity: 0.3, shadowRadius: 6 },
  statusRow: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 12 },
  statusStep: { fontSize: 18, fontWeight: 'bold', color: '#000', marginHorizontal: 4 },
});

export default DriverScreen;
