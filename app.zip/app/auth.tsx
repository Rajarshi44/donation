import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

const colors = {
  yellow: '#ffcc00',
  cyan: '#00ccff',
  pink: '#ff0066',
  black: '#000',
  white: '#fff',
};

export default function AuthScreen() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleAuth = () => {
    // Mock login/signup, just redirect
    router.replace('/(tabs)/dashboard');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>🍕🥗🚚❤️</Text>
      <Text style={styles.title}>{isLogin ? 'Login' : 'Sign Up'}</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        placeholderTextColor={colors.black}
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor={colors.black}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <TouchableOpacity style={[styles.button, { backgroundColor: isLogin ? colors.yellow : colors.cyan }]} onPress={handleAuth}>
        <Text style={styles.buttonText}>{isLogin ? 'Login' : 'Sign Up'}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setIsLogin(!isLogin)}>
        <Text style={styles.switchText}>
          {isLogin ? "Don't have an account? Sign Up" : 'Already have an account? Login'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  logo: {
    fontSize: 48,
    marginBottom: 16,
    textShadowColor: colors.yellow,
    textShadowOffset: { width: 4, height: 4 },
    textShadowRadius: 4,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: colors.black,
    marginBottom: 24,
    textShadowColor: colors.cyan,
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 2,
  },
  input: {
    width: '100%',
    backgroundColor: colors.yellow,
    borderWidth: 3,
    borderColor: colors.black,
    borderRadius: 12,
    fontSize: 20,
    marginBottom: 16,
    padding: 12,
    color: colors.black,
    fontWeight: 'bold',
    shadowColor: colors.pink,
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  button: {
    width: '100%',
    borderWidth: 3,
    borderColor: colors.black,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: colors.black,
    shadowOffset: { width: 4, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  buttonText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.black,
    letterSpacing: 1,
  },
  switchText: {
    color: colors.pink,
    fontWeight: 'bold',
    fontSize: 16,
    marginTop: 8,
    textShadowColor: colors.yellow,
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 1,
  },
});
